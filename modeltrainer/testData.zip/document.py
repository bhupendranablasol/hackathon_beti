import sys
import json
import spacy

def extract_entities(text, nlp_person, nlp_custom):
    print("Extracting entities...")
    doc = nlp_person(text)  # Using pre-built spaCy model for persons
    entities = {"names": [], "emails": [], "ssns": []}

    for ent in doc.ents:
        if ent.label_ == "PERSON":
            entities["names"].append(ent.text)

    doc = nlp_custom(text)  # Using custom-trained spaCy model for emails and SSNs
    for ent in doc.ents:
        if ent.label_ == "EMAIL":
            entities["emails"].append(ent.text)
        elif ent.label_ == "SSN":
            entities["ssns"].append(ent.text)

    return entities

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python script.py <input_file>")
        sys.exit(1)

    input_file = sys.argv[1]

    # Load pre-built spaCy model for persons
    print("Loading pre-built spaCy model...")
    nlp_person = spacy.load("en_core_web_sm")

    # Load your custom-trained model for emails and SSNs
    # Replace 'ner_model' with the actual path to your trained model
    model_path_custom = "../modeltrainer/ner_model"
    print("Loading custom spaCy model...")
    nlp_custom = spacy.load(model_path_custom)

    with open(input_file, 'r', encoding='utf-8') as file:
        text = file.read()

    entities = extract_entities(text, nlp_person, nlp_custom)
    print("Entities extracted:")
    print(json.dumps(entities))
